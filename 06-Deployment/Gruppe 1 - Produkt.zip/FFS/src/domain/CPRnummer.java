package domain;

public interface CPRnummer {

	public abstract int getCPR_id();

	public abstract void setCPR_id(int cPR_id);

	public abstract String getCPRnummer();

	public abstract void setCPRnummer(String cPRnummer);

}