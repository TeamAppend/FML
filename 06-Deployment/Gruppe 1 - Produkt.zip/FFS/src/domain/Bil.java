package domain;

public interface Bil {
	public int getBil_id();
	
	public void setBil_id(int bil_id);
	
	public double getPris();
	
	public void setPris(double pris);
	
	public void setModelnavn(String modelnavn);
	
	public String getModelnavn();
}
