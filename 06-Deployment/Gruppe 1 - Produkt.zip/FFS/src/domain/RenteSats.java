package domain;

public interface RenteSats {

	public abstract void setRenteSats(CallBack callBack);

	public abstract double getRenteSats();

}