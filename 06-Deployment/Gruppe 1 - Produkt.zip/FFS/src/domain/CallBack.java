package domain;
public abstract class CallBack {
	public abstract void onRequestComplete();
}