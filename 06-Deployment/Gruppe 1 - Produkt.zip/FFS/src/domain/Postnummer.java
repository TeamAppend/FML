package domain;

public interface Postnummer {

	public abstract String getPostnummer();

	public abstract void setPostnummer(String postnummer);

	public abstract String getBynavn();

	public abstract void setBynavn(String bynavn);

}