package exceptions;

public class LånetilbudDoesNotExistsException extends Exception {

}
