package exceptions;

public class BilDoesNotExistException extends Exception {

}
