package exceptions;

public class PostnummerDoesNotExistException extends Exception {

}
