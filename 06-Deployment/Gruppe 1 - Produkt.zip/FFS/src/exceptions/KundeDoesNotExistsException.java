package exceptions;

public class KundeDoesNotExistsException extends Exception {

}
