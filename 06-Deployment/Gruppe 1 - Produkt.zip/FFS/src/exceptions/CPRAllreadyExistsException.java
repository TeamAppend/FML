package exceptions;

public class CPRAllreadyExistsException extends Exception {

}
