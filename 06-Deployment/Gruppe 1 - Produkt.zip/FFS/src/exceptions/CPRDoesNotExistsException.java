package exceptions;

public class CPRDoesNotExistsException extends Exception {

}
