package exceptions;

public class LånetilbudAllreadyExistsException extends Exception {

}
