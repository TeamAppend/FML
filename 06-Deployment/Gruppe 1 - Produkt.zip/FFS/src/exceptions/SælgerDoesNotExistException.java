package exceptions;

public class SælgerDoesNotExistException extends Exception {

}
