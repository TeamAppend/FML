package exceptions;

public class KundeAllreadyExistsException extends Exception {

}
