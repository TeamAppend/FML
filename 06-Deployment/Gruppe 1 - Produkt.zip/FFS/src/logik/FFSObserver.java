package logik;

public interface FFSObserver {
	
	public void update(Object source, String s);

}
