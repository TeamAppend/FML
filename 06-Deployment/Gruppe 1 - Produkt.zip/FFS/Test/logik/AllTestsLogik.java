package logik;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({KundeControllerTest.class, PostnummerLogikTest.class})
public class AllTestsLogik {

}
